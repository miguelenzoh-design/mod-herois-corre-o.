package br.herolite;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class Rede {
    private static final String V = "2";

    public static final SimpleChannel CANAL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(HeroLite.ID, "main"), () -> V, V::equals, V::equals);

    private Rede() {}

    public static void registrar() {
        CANAL.registerMessage(0, Acao.class, Acao::codificar, Acao::decodificar, Acao::tratar);
        CANAL.registerMessage(1, Sync.class, Sync::codificar, Sync::decodificar, Sync::tratar);
    }

    /** Cliente -> servidor: 0 voar/sentidos, 1..3 habilidades, 4 golpe máximo/item, 5 modo contido/total. */
    public static final class Acao {
        final int id;

        public Acao(int id) {
            this.id = id;
        }

        static void codificar(Acao a, FriendlyByteBuf b) {
            b.writeByte(a.id);
        }

        static Acao decodificar(FriendlyByteBuf b) {
            return new Acao(b.readByte());
        }

        static void tratar(Acao a, Supplier<NetworkEvent.Context> c) {
            NetworkEvent.Context ctx = c.get();
            ctx.enqueueWork(() -> {
                ServerPlayer p = ctx.getSender();
                if (p != null) Herois.acao(p, a.id);
            });
            ctx.setPacketHandled(true);
        }
    }

    /** Servidor -> cliente: medidor de energia e modo, para desenhar o HUD. */
    public static final class Sync {
        final int tipo;
        final int energia;
        final int modo;

        public Sync(int tipo, int energia, int modo) {
            this.tipo = tipo;
            this.energia = energia;
            this.modo = modo;
        }

        static void codificar(Sync s, FriendlyByteBuf b) {
            b.writeByte(s.tipo);
            b.writeShort(s.energia);
            b.writeByte(s.modo);
        }

        static Sync decodificar(FriendlyByteBuf b) {
            return new Sync(b.readByte(), b.readShort(), b.readByte());
        }

        static void tratar(Sync s, Supplier<NetworkEvent.Context> c) {
            NetworkEvent.Context ctx = c.get();
            ctx.enqueueWork(() -> {
                EstadoCliente.tipo = s.tipo;
                EstadoCliente.energia = s.energia;
                EstadoCliente.modo = s.modo;
            });
            ctx.setPacketHandled(true);
        }
    }
}
