package br.herolite;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HeroLite.ID)
public final class Eventos {
    private Eventos() {}

    @SubscribeEvent
    public static void tickServidor(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        try {
            H.rodar();
        } catch (Exception ignorado) {
        }
    }

    @SubscribeEvent
    public static void tickJogador(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.player instanceof ServerPlayer p) || p.tickCount % 10 != 0) return;
        try {
            Heroi h = Herois.atual(p);
            CompoundTag d = Herois.dados(p);

            String ultimo = d.getString("ultimo");
            String agora = h == null ? "" : h.id;
            if (!agora.equals(ultimo)) {
                d.putString("ultimo", agora);
                if (h != null) Herois.aviso(p, h);
            }

            Herois.voo(p, h);
            Acess.tick(p);
            PoderProprio.tick(p);
            Cosmico.tick(p);
            Enzo.tick(p);

            if (h != null) {
                Mec.tick(p, h);
                if (Herois.kryptonita(p, h)) {
                    p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 2, true, false, false));
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, true, false, false));
                    p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 60, 0, true, false, false));
                } else {
                    int extra = Estado.ampExtra(p, h);
                    for (Heroi.Pass x : h.pass) {
                        int dur = x.ef() == MobEffects.NIGHT_VISION ? 240 : 40;
                        int amp = Math.min(6, x.amp() + extra);
                        p.addEffect(new MobEffectInstance(x.ef(), dur, amp, true, false, false));
                    }
                    if (Mec.tipo(h) == Mec.Tipo.SOLAR) {
                        int nv = Estado.energia(p) / 250;
                        if (nv >= 2) p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, nv / 2, true, false, false));
                    }
                }
            }
            Estado.sync(p);
        } catch (Exception ignorado) {
        }
    }

    /** Dano: fraquezas do traje (vítima) e força/contenção do herói (atacante). */
    @SubscribeEvent
    public static void dano(LivingHurtEvent e) {
        LivingEntity vit = e.getEntity();
        if (vit instanceof ServerPlayer v) {
            Heroi hv = Herois.atual(v);
            if (hv != null) {
                e.setAmount(Mec.recebido(v, hv, e.getSource(), e.getAmount()));
                if (e.getAmount() <= 0f) {
                    e.setCanceled(true);
                    return;
                }
            }
        }
        if (e.getSource().getEntity() instanceof ServerPlayer p && !H.interno) {
            Heroi h = Herois.atual(p);
            if (h == null) return;
            float a = e.getAmount() * Estado.multDano(p);
            if (Estado.total(p) && Estado.bom(h) && vit.getMaxHealth() >= 100f) a *= 1.8f;
            if (Estado.contido(p)) {
                float max = vit.getHealth() - 1f;
                if (max <= 0f) {
                    e.setCanceled(true);
                    return;
                }
                a = Math.min(a, max);
            }
            e.setAmount(a);
            if (Mec.tipo(h) == Mec.Tipo.FURIA) Estado.addEnergia(p, 10);
        }
    }

    /** Esquiva (Aranha, Demolidor, Deadpool), reflexo de projéteis e imunidade a raios. */
    @SubscribeEvent
    public static void ataque(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        DamageSource src = e.getSource();
        Heroi h = Herois.atual(p);
        if (h != null && (h.id.equals("spider_man") || h.id.equals("daredevil") || h.id.equals("deadpool"))
                && src.getEntity() instanceof LivingEntity && Math.random() < 0.25) {
            e.setCanceled(true);
            p.serverLevel().sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 8, 0.3, 0.5, 0.3, 0.05);
            H.msg(p, "Esquivou!");
            return;
        }
        if (src.getDirectEntity() instanceof Projectile pr && Acess.reflete(p)) {
            e.setCanceled(true);
            Vec3 v = pr.getDeltaMovement().scale(-1.0);
            pr.setDeltaMovement(v);
            pr.setOwner(p);
            pr.hurtMarked = true;
            return;
        }
        if (src.is(DamageTypes.LIGHTNING_BOLT) && Mec.temMartelo(p)) e.setCanceled(true);
    }

    /** Quem veste um traje completo sofre bem menos dano de queda. */
    @SubscribeEvent
    public static void queda(LivingFallEvent e) {
        if (e.getEntity() instanceof Player p && Herois.atual(p) != null) {
            e.setDistance(Math.max(0f, e.getDistance() - 15f));
        }
    }

    @SubscribeEvent
    public static void entrou(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            CompoundTag d = Herois.dados(p);
            d.putBoolean("voo", false);
            d.putString("ultimo", "");
            if (d.getBoolean("voo_dado") && !p.isCreative() && !p.isSpectator()) {
                p.getAbilities().mayfly = false;
                p.getAbilities().flying = false;
                p.getAbilities().setFlyingSpeed(0.05f);
                d.putBoolean("voo_dado", false);
                p.onUpdateAbilities();
            }
        }
    }

    @SubscribeEvent
    public static void clonou(PlayerEvent.Clone e) {
        if (!e.isWasDeath()) return;
        CompoundTag antigo = e.getOriginal().getPersistentData();
        if (antigo.contains("PlayerPersisted", 10)) {
            CompoundTag c = antigo.getCompound("PlayerPersisted").copy();
            c.putBoolean("voo", false);
            c.putBoolean("voo_dado", false);
            c.putString("ultimo", "");
            c.putInt("en", 0);
            e.getEntity().getPersistentData().put("PlayerPersisted", c);
        }
    }

    @SubscribeEvent
    public static void parando(ServerStoppingEvent e) {
        H.limparAgenda();
    }
}
