package br.herolite;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HeroLite.ID, value = Dist.CLIENT)
public final class ClienteForge {
    private ClienteForge() {}

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (Minecraft.getInstance().player == null) return;
        for (int i = 0; i < ClienteMod.TECLAS.length; i++) {
            while (ClienteMod.TECLAS[i].consumeClick()) {
                Rede.CANAL.sendToServer(new Rede.Acao(i));
            }
        }
    }
}
