package br.herolite;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HeroLite.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClienteMod {
    public static final KeyMapping[] TECLAS = new KeyMapping[7];

    static {
        String[] nomes = {"toggle", "hab1", "hab2", "hab3", "hab4", "modo", "hab5"};
        int[] teclas = {InputConstants.KEY_R, InputConstants.KEY_V, InputConstants.KEY_B,
                InputConstants.KEY_N, InputConstants.KEY_H, InputConstants.KEY_G, InputConstants.KEY_Z};
        for (int i = 0; i < 7; i++) {
            TECLAS[i] = new KeyMapping("key.herolite." + nomes[i], teclas[i], "key.categories.herolite");
        }
    }

    private ClienteMod() {}

    @SubscribeEvent
    public static void registrar(RegisterKeyMappingsEvent e) {
        for (KeyMapping k : TECLAS) e.register(k);
    }
}
