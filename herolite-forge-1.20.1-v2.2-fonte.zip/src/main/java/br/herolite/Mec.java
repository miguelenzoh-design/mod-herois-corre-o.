package br.herolite;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Mecânicas por herói: medidores de energia, fraquezas e golpe máximo (tecla H). */
public final class Mec {
    public enum Tipo { NENHUM, SOLAR, CINETICA, FURIA, CARGA, TEMPESTADE, COSMICO }

    private Mec() {}

    public static Tipo tipo(Heroi h) {
        if (h == null) return Tipo.NENHUM;
        return switch (h.id) {
            case "superman", "supergirl" -> Tipo.SOLAR;
            case "black_panther" -> Tipo.CINETICA;
            case "hulk" -> Tipo.FURIA;
            case "iron_man", "green_lantern", "cyborg", "cyclops" -> Tipo.CARGA;
            case "thor", "storm" -> Tipo.TEMPESTADE;
            case "superman_cosmic", "phoenix", "morte", "presenca", "galactus", "eternidade", "tribunal", "anti_monitor", "spectre", "enzo_dark_lord", "enzo_cosmic" -> Tipo.COSMICO;
            default -> Tipo.NENHUM;
        };
    }

    public static String nome(Tipo t) {
        return switch (t) {
            case SOLAR -> "SOL";
            case CINETICA -> "CINÉTICA";
            case FURIA -> "FÚRIA";
            case CARGA -> "CARGA";
            case TEMPESTADE -> "TEMPESTADE";
            case COSMICO -> "COSMOS";
            default -> "";
        };
    }

    public static int cor(Tipo t) {
        return switch (t) {
            case SOLAR -> 0xFF9A1F;
            case CINETICA -> 0xA050FF;
            case FURIA -> 0x45E05A;
            case CARGA -> 0x3FD8FF;
            case TEMPESTADE -> 0x9CC8FF;
            case COSMICO -> 0xB070FF;
            default -> 0xFFFFFF;
        };
    }

    static boolean tem(Player p, Item it) {
        int n = p.getInventory().getContainerSize();
        for (int i = 0; i < n; i++) if (p.getInventory().getItem(i).is(it)) return true;
        return false;
    }

    public static boolean temMartelo(Player p) {
        return tem(p, HeroLite.MJOLNIR.get()) || tem(p, HeroLite.STORMBREAKER.get());
    }

    /** Velocidade de voo: o Superman voa mais rápido com mais energia solar; sem carga, sem voo. */
    public static float velVoo(Player p, Heroi h) {
        float base = h.voo;
        int e = Estado.energia(p);
        Tipo t = tipo(h);
        if (t == Tipo.SOLAR) return base * (0.6f + 0.8f * e / Estado.MAX);
        if (t == Tipo.CARGA && e <= 0) return 0f;
        if (Estado.bom(h) && Estado.total(p)) base *= 1.25f;
        return base;
    }

    private static void aura(ServerPlayer p, int cor) {
        p.serverLevel().sendParticles(Efeitos.dust(cor, 1.1f), p.getX(), p.getY() + 1.0, p.getZ(), 6, 0.4, 0.8, 0.4, 0);
    }

    /** A cada 10 ticks com traje completo. */
    public static void tick(ServerPlayer p, Heroi h) {
        Tipo t = tipo(h);
        ServerLevel w = p.serverLevel();
        CompoundTag d = Estado.d(p);
        int e = Estado.energia(p);
        switch (t) {
            case SOLAR -> {
                boolean sol = w.dimension() == Level.OVERWORLD && w.isDay() && !w.isRaining() && w.canSeeSky(p.blockPosition().above());
                boolean vermelho = w.dimension() != Level.OVERWORLD;
                boolean krip = Herois.kryptonita(p, h);
                if (krip) e -= 12;
                else if (sol) e += 6;
                else if (vermelho) e -= 4;
                else e -= 1;
                Estado.setEnergia(p, e);
                e = Estado.energia(p);
                if (sol && !krip && e < Estado.MAX) {
                    w.sendParticles(Efeitos.dust(0xFFC040, 0.9f), p.getX(), p.getY() + 1.0, p.getZ(), 3, 0.4, 0.8, 0.4, 0);
                }
                if (e < 100 && !krip) p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 0, true, false, false));
            }
            case CINETICA -> Estado.addEnergia(p, -1);
            case COSMICO -> Estado.addEnergia(p, 4);
            case FURIA -> Estado.addEnergia(p, -3);
            case CARGA -> {
                if (p.getAbilities().flying) Estado.addEnergia(p, -6);
                else Estado.addEnergia(p, 4);
                if (p.isInWater() && h.id.equals("iron_man")) {
                    Estado.addEnergia(p, -80);
                    H.msg(p, "Curto-circuito! O traje não gosta de água.");
                }
            }
            case TEMPESTADE -> {
                if (w.isThundering()) e += 8;
                else if (w.isRaining()) e += 3;
                else e -= 1;
                if (temMartelo(p) && e < Estado.MAX) e += 1;
                Estado.setEnergia(p, e);
                e = Estado.energia(p);
                if (e >= Estado.MAX && Estado.total(p)) {
                    for (LivingEntity a : H.area(p, 12)) {
                        if (a instanceof net.minecraft.world.entity.monster.Monster && Math.random() < 0.15) {
                            H.raioVisual(p, a.position());
                            H.dano(p, a, 8f);
                            Estado.addEnergia(p, -60);
                            break;
                        }
                    }
                }
            }
            default -> { }
        }
        e = Estado.energia(p);
        // auge: aviso e aura quando o medidor chega ao máximo
        if (t != Tipo.NENHUM && t != Tipo.CARGA) {
            boolean auge = d.getBoolean("auge");
            if (e >= Estado.MAX) {
                aura(p, cor(t));
                if (!auge) {
                    d.putBoolean("auge", true);
                    H.msg(p, "AUGE! Poder no máximo!");
                    H.som(p, SoundEvents.BEACON_ACTIVATE, 1.2f, 1.4f);
                    Efeitos.anel(p, 6, cor(t), null);
                }
            } else if (e < Estado.MAX * 0.9) {
                d.putBoolean("auge", false);
            }
        }
        fraquezas(p, h, d);
    }

    private static void fraquezas(ServerPlayer p, Heroi h, CompoundTag d) {
        switch (h.id) {
            case "aquaman" -> {
                int seco = d.getInt("seco");
                seco = p.isInWaterRainOrBubble() ? 0 : seco + 1;
                d.putInt("seco", seco);
                if (seco > 360) {
                    p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1, true, false, false));
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, true, false, false));
                    if (seco % 60 == 0) H.msg(p, "Desidratado! Volte para a água.");
                }
            }
            case "flash" -> {
                if (p.isSprinting()) p.causeFoodExhaustion(0.6f);
            }
            case "martian_manhunter", "venom" -> {
                if (p.isOnFire() || p.isInLava()) {
                    p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1, true, false, false));
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, true, false, false));
                }
            }
            case "human_torch" -> {
                if (p.isInWater()) {
                    p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1, true, false, false));
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, true, false, false));
                }
            }
            case "wolverine" -> {
                if (p.getHealth() < p.getMaxHealth() * 0.35f) {
                    p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 2, true, false, false));
                }
            }
            default -> { }
        }
    }

    /** Dano recebido pelo portador do traje: fraquezas, absorção e resistências. */
    public static float recebido(ServerPlayer p, Heroi h, DamageSource src, float a) {
        if (Enzo.semFraqueza(h)) return a;
        if (src.is(DamageTypes.SONIC_BOOM)) a *= h.resist >= 3 ? 0.3f : (h.resist >= 2 ? 0.5f : 0.8f);
        boolean fogo = src.is(DamageTypeTags.IS_FIRE);
        boolean magia = src.is(DamageTypes.MAGIC) || src.is(DamageTypes.INDIRECT_MAGIC);
        switch (h.id) {
            case "superman", "supergirl" -> {
                if (magia) a *= 1.5f;
            }
            case "martian_manhunter", "venom" -> {
                if (fogo) a *= 2.0f;
            }
            case "human_torch", "ghost_rider" -> {
                if (fogo) return 0f;
            }
            case "thor", "storm" -> {
                if (src.is(DamageTypes.LIGHTNING_BOLT)) return 0f;
            }
            case "iron_man" -> {
                if (src.is(DamageTypes.LIGHTNING_BOLT)) {
                    Estado.addEnergia(p, -400);
                    H.msg(p, "EMP! O traje sobrecarregou.");
                }
            }
            default -> { }
        }
        Tipo t = tipo(h);
        boolean real = !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
        if (t == Tipo.CINETICA && real) {
            float abs = a * 0.5f;
            Estado.addEnergia(p, (int) (abs * 35));
            a -= abs;
        }
        if (t == Tipo.FURIA && real) Estado.addEnergia(p, (int) (a * 40));
        if (t == Tipo.SOLAR && Estado.energia(p) >= Estado.MAX) a *= 0.7f;
        return a;
    }

    // ---------- golpe máximo (tecla H com traje) ----------

    private static boolean gastar(ServerPlayer p, int custo, String falta) {
        if (Estado.energia(p) < custo) {
            H.msg(p, falta);
            return false;
        }
        Estado.addEnergia(p, -custo);
        return true;
    }

    /** Descarga cinética do Pantera Negra: devolve toda a energia absorvida. */
    public static boolean descarga(ServerPlayer p, boolean maxima) {
        int e = Estado.energia(p);
        if (e < (maxima ? 600 : 100)) {
            H.msg(p, "Pouca energia cinética absorvida (" + e + "/" + (maxima ? 600 : 100) + ")");
            return false;
        }
        double raio = 5 + e / 150.0;
        float dmg = (4f + e / 40f) * (maxima ? 2f : 1f);
        Estado.setEnergia(p, 0);
        Efeitos.anel(p, raio, 0xA050FF, ParticleTypes.ELECTRIC_SPARK);
        Efeitos.explosaoVisual(p.serverLevel(), p.position(), 0xA050FF, 3f);
        for (LivingEntity a : H.area(p, raio)) {
            H.dano(p, a, dmg);
            Vec3 v = a.position().subtract(p.position()).normalize().scale(1.4);
            a.setDeltaMovement(v.x, 0.5, v.z);
            a.hurtMarked = true;
        }
        return true;
    }

    public static boolean ultimo(ServerPlayer p, Heroi h) {
        if (Enzo.eh(h)) {
            Enzo.hab(p, 4);
            return true;
        }
        CompoundTag d = Estado.d(p);
        long agora = p.level().getGameTime();
        long fim = d.getLong("cd4");
        if (agora < fim && !Estado.semCd(p)) {
            H.msg(p, "Recarregando: " + ((fim - agora) / 20 + 1) + "s");
            return true;
        }
        int cd = 200;
        boolean ok;
        switch (tipo(h)) {
            case SOLAR -> {
                int e = Estado.energia(p);
                if (e >= Estado.MAX) {
                    Estado.addEnergia(p, -700);
                    H.msg(p, "SUPERNOVA SOLAR!");
                    Efeitos.anel(p, 14, 0xFFB000, ParticleTypes.FLAME);
                    Efeitos.explosaoVisual(p.serverLevel(), p.position(), 0xFFB000, 5f);
                    for (LivingEntity a : H.area(p, 14)) {
                        H.dano(p, a, 16f);
                        if (!Estado.contido(p)) a.setSecondsOnFire(6);
                        Vec3 v = a.position().subtract(p.position()).normalize().scale(1.6);
                        a.setDeltaMovement(v.x, 0.6, v.z);
                        a.hurtMarked = true;
                    }
                    ok = true;
                } else if (e >= 500) {
                    Estado.addEnergia(p, -250);
                    H.msg(p, "Raio Solar!");
                    Efeitos.feixe(p, 50, 60, 3.4f, 0xFF3A10, 0xFFF0B0, true, 1.9f);
                    ok = true;
                } else {
                    H.msg(p, "Precisa de 500 de energia solar (barra laranja). Fique ao sol!");
                    ok = false;
                }
            }
            case CINETICA -> ok = descarga(p, true);
            case FURIA -> {
                ok = gastar(p, 500, "Precisa de 500 de fúria (apanhe um pouco!)");
                if (ok) {
                    H.msg(p, "HULK ESMAGA TUDO!");
                    H.efeito(p, MobEffects.DAMAGE_BOOST, 15, 4);
                    H.efeito(p, MobEffects.DAMAGE_RESISTANCE, 15, 2);
                    H.efeito(p, MobEffects.MOVEMENT_SPEED, 15, 1);
                    Efeitos.anel(p, 8, 0x45E05A, ParticleTypes.CLOUD);
                }
            }
            case CARGA -> {
                ok = gastar(p, 700, "Precisa de 700 de carga");
                if (ok) {
                    H.msg(p, "SOBRECARGA!");
                    Efeitos.feixe(p, 50, 50, 3.4f, h.cor1, 0xFFFFFF, false, 1.8f);
                    Efeitos.anel(p, 6, h.cor1, null);
                }
            }
            case COSMICO -> {
                ok = gastar(p, 500, "Precisa de 500 de cosmos (espere a barra roxa encher)");
                if (ok) Cosmico.supremo(p, h);
            }
            case TEMPESTADE -> {
                ok = gastar(p, 600, "Precisa de 600 de tempestade (espere a chuva)");
                if (ok) {
                    H.msg(p, "RAGNAROK!");
                    p.getServer().overworld().setWeatherParameters(0, 6000, true, true);
                    int n = 0;
                    for (LivingEntity a : H.area(p, 16)) {
                        if (n++ >= 8) break;
                        H.raioEm(p, a, 10f);
                    }
                }
            }
            default -> {
                if (Estado.bom(h) && !Estado.total(p)) {
                    H.msg(p, "Só no modo TOTAL (tecla G). Você está se contendo.");
                    ok = false;
                } else {
                    cd = 3000;
                    ok = true;
                    H.msg(p, "PODER MÁXIMO!");
                    H.efeito(p, MobEffects.DAMAGE_BOOST, 12, 3);
                    H.efeito(p, MobEffects.MOVEMENT_SPEED, 12, 2);
                    H.efeito(p, MobEffects.DAMAGE_RESISTANCE, 12, 2);
                    Efeitos.anel(p, 9, h.cor1, ParticleTypes.CRIT);
                    for (LivingEntity a : H.area(p, 9)) {
                        H.dano(p, a, 9f);
                        Vec3 v = a.position().subtract(p.position()).normalize().scale(1.3);
                        a.setDeltaMovement(v.x, 0.5, v.z);
                        a.hurtMarked = true;
                    }
                }
            }
        }
        if (ok) d.putLong("cd4", agora + cd);
        return true;
    }
}
