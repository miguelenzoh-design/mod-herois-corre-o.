package br.herolite;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tiers;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.HashMap;
import java.util.Map;

@Mod(HeroLite.ID)
public class HeroLite {
    public static final String ID = "herolite";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<CreativeModeTab> ABAS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    // itens icônicos
    public static final RegistryObject<Item> TECIDO = ITEMS.register("hero_fabric", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> MJOLNIR = ITEMS.register("mjolnir", Itens.MjolnirItem::new);
    public static final RegistryObject<Item> ESCUDO = ITEMS.register("captain_shield", Itens.EscudoItem::new);
    public static final RegistryObject<Item> GARRAS = ITEMS.register("adamantium_claws", Itens.GarrasItem::new);
    public static final RegistryObject<Item> BATARANG = ITEMS.register("batarang", Itens.BatarangItem::new);
    public static final RegistryObject<Item> LACO = ITEMS.register("lasso_of_truth", Itens.LacoItem::new);
    public static final RegistryObject<Item> LANCA_TEIA = ITEMS.register("web_shooter", () -> new Itens.GanchoItem(true));
    public static final RegistryObject<Item> GANCHO = ITEMS.register("grapple_gun", () -> new Itens.GanchoItem(false));
    public static final RegistryObject<Item> MANOPLA = ITEMS.register("infinity_gauntlet", Itens.ManoplaItem::new);
    public static final RegistryObject<Item> SORO_SOLDADO = ITEMS.register("super_soldier_serum", () -> new Itens.SoroItem(false));
    public static final RegistryObject<Item> SORO_GAMA = ITEMS.register("gamma_serum", () -> new Itens.SoroItem(true));
    public static final RegistryObject<Item> STORMBREAKER = ITEMS.register("stormbreaker", Itens.StormbreakerItem::new);
    public static final RegistryObject<Item> LANCA_VIBR = ITEMS.register("vibranium_spear", () -> new Itens.ArmaHabItem(Tiers.NETHERITE, 3, -2.0f, 30, false,
            p -> H.tiro(p, 26, 7f, ParticleTypes.ELECTRIC_SPARK)));
    public static final RegistryObject<Item> TRIDENTE = ITEMS.register("aquaman_trident", () -> new Itens.ArmaHabItem(Tiers.NETHERITE, 4, -2.2f, 50, true,
            p -> { H.onda(p, 6, 7f, 1.0, ParticleTypes.BUBBLE_POP); H.relampago(p, 25); }));
    public static final RegistryObject<Item> GODKILLER = ITEMS.register("godkiller", () -> new Itens.ArmaHabItem(Tiers.NETHERITE, 6, -2.4f, 60, true,
            p -> { Efeitos.anel(p, 5, 0xFFD040, ParticleTypes.END_ROD); H.onda(p, 5, 12f, 1.0, ParticleTypes.CRIT); }));
    public static final RegistryObject<Item> PISTOLA = ITEMS.register("repulsor_pistol", () -> new Itens.GadgetItem(1, 12, false, false,
            p -> Efeitos.feixe(p, 30, 6, 4f, 0x55CCFF, 0xFFFFFF, false, 0.9f)));
    public static final RegistryObject<Item> BATARANG_EXP = ITEMS.register("explosive_batarang", () -> new Itens.GadgetItem(16, 20, true, false,
            p -> { var a = H.tiro(p, 28, 4f, ParticleTypes.CRIT); if (a != null) H.explodirEm(p, a, 5f); }));
    // sistema cósmico: distribuição de poder
    public static final RegistryObject<Item> CORACAO = ITEMS.register("cosmic_heart", Cosmico.Coracao::new);
    public static final RegistryObject<Item> CANALIZADOR = ITEMS.register("cosmic_conduit", Cosmico.Canalizador::new);
    public static final RegistryObject<Item> FRAGMENTO = ITEMS.register("cosmic_fragment", Cosmico.Fragmento::new);
    public static final RegistryObject<Item> CETRO = ITEMS.register("cosmic_scepter", Cosmico.Cetro::new);
    public static final RegistryObject<Item> BARRA_VIBR = ITEMS.register("vibranium_bar", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> CRISTAL = ITEMS.register("power_crystal", () -> new Item(new Item.Properties().rarity(net.minecraft.world.item.Rarity.EPIC)));
    public static final RegistryObject<Item> KRYPTONITA = ITEMS.register("kryptonite", () -> new Item(new Item.Properties()));

    // Enzo Dark Lord: so por comando do dono
    public static final RegistryObject<Item> CRISTAL_CELESTIAL = ITEMS.register("celestial_crystal", () -> new Item(new Item.Properties().stacksTo(1).fireResistant().rarity(net.minecraft.world.item.Rarity.EPIC)));
    public static final RegistryObject<Item> NUCLEO = ITEMS.register("dark_core", Enzo.NucleoItem::new);

    // acessórios com poder próprio
    static {
        for (String n : Acess.NOMES) {
            if (n.equals("mjolnir") || n.equals("stormbreaker") || n.equals("captain_shield")) continue;
            ITEMS.register(n, () -> new Itens.AcessorioItem(n));
        }
        for (String b : new String[]{"thanos", "ultron", "doomsday", "darkseid", "doom", "galactus", "antimonitor", "fenix_negra"}) {
            ITEMS.register("summon_" + b, () -> new Itens.InvocadorItem("boss_" + b));
        }
    }

    // trajes (4 peças por herói) e emblemas
    public static final Map<String, RegistryObject<Item>> PECAS = new HashMap<>();

    static {
        for (Heroi h : Heroi.values()) {
            MatHeroi mat = new MatHeroi(h);
            for (ArmorItem.Type t : ArmorItem.Type.values()) {
                String nome = h.id + "_" + sufixo(t);
                PECAS.put(nome, ITEMS.register(nome, () -> new Itens.HeroiArmor(mat, t, h)));
            }
            ITEMS.register(h.id + "_emblem", () -> new Item(new Item.Properties()));
        }
    }

    public static String sufixo(ArmorItem.Type t) {
        return switch (t) {
            case HELMET -> "helmet";
            case CHESTPLATE -> "chestplate";
            case LEGGINGS -> "leggings";
            case BOOTS -> "boots";
        };
    }

    public static final RegistryObject<CreativeModeTab> ABA = ABAS.register("herolite", () -> CreativeModeTab.builder()
            .title(Component.literal("Hero Lite"))
            .icon(() -> new ItemStack(PECAS.get("superman_chestplate").get()))
            .displayItems((params, out) -> {
                for (RegistryObject<Item> i : ITEMS.getEntries()) {
                    String n = i.getId().getPath();
                    if (n.startsWith("enzo_") || n.equals("celestial_crystal") || n.equals("dark_core")) continue;
                    out.accept(i.get());
                }
                for (RegistryObject<Item> i : Mobs.OVOS.getEntries()) out.accept(i.get());
            })
            .build());

    public HeroLite() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        ABAS.register(bus);
        Mobs.registrar(bus);
        Rede.registrar();
    }
}
