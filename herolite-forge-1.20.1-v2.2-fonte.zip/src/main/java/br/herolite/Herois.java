package br.herolite;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Estado de herói de cada jogador: traje completo (4 peças iguais) = poderes. */
public final class Herois {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private Herois() {}

    static CompoundTag dados(Player p) {
        CompoundTag raiz = p.getPersistentData();
        if (!raiz.contains("PlayerPersisted", 10)) raiz.put("PlayerPersisted", new CompoundTag());
        return raiz.getCompound("PlayerPersisted");
    }

    /** Herói atual = traje completo do mesmo herói; senão null. */
    public static Heroi atual(Player p) {
        Heroi h = null;
        for (EquipmentSlot s : SLOTS) {
            ItemStack st = p.getItemBySlot(s);
            if (!(st.getItem() instanceof Itens.HeroiArmor a)) return null;
            if (h == null) h = a.heroi;
            else if (h != a.heroi) return null;
        }
        if (h != null && Enzo.eh(h) && !Enzo.autorizado(p)) return null;
        if (h != null && Enzo.desativado(h)) return null;
        return h;
    }

    /** Kryptonita no inventário enfraquece Superman e Supergirl. */
    public static boolean kryptonita(Player p, Heroi h) {
        if (h != Heroi.SUPERMAN && h != Heroi.SUPERGIRL) return false;
        if (Enzo.semFraqueza(h)) return false;
        return Mec.tem(p, HeroLite.KRYPTONITA.get());
    }

    /** Mantém o voo de acordo com o traje e a tecla R. */
    public static void voo(ServerPlayer p, Heroi h) {
        if (p.isCreative() || p.isSpectator()) return;
        CompoundTag d = dados(p);
        float v = h == null ? 0f : Mec.velVoo(p, h);
        boolean quer = h != null && h.voo > 0 && d.getBoolean("voo") && v > 0f && !kryptonita(p, h);
        Abilities ab = p.getAbilities();
        if (quer) {
            if (!ab.mayfly || Math.abs(ab.getFlyingSpeed() - v) > 0.001f) {
                ab.mayfly = true;
                ab.setFlyingSpeed(v);
                d.putBoolean("voo_dado", true);
                p.onUpdateAbilities();
            }
        } else if (d.getBoolean("voo_dado")) {
            ab.mayfly = false;
            ab.flying = false;
            ab.setFlyingSpeed(0.05f);
            d.putBoolean("voo_dado", false);
            d.putBoolean("voo", false);
            p.onUpdateAbilities();
        }
    }

    /** 0 = voo/sentidos, 1..3 = habilidades, 4 = golpe máximo/item/poder próprio, 5 = modo contido/total. */
    public static void acao(ServerPlayer p, int id) {
        if (id == 6) {
            Enzo.quinta(p);
            return;
        }
        if (id == 5) {
            modo(p);
            return;
        }
        if (id == 4) {
            quarta(p);
            return;
        }
        Heroi h = atual(p);
        if (h == null) {
            H.msg(p, "Vista o traje completo de um herói (4 peças).");
            return;
        }
        if (kryptonita(p, h)) {
            H.msg(p, "Kryptonita! Seus poderes falham.");
            return;
        }
        CompoundTag d = dados(p);
        long agora = p.level().getGameTime();

        if (id == 0) {
            if (Enzo.eh(h)) {
                Enzo.sentidos(p);
                return;
            }
            if (h.voo > 0) {
                boolean novo = !d.getBoolean("voo");
                d.putBoolean("voo", novo);
                voo(p, h);
                if (novo && p.getAbilities().mayfly) {
                    p.getAbilities().flying = true;
                    p.onUpdateAbilities();
                    p.setDeltaMovement(0, 0.4, 0);
                    p.hurtMarked = true;
                }
                if (novo && !p.getAbilities().mayfly && !p.isCreative()) {
                    d.putBoolean("voo", false);
                    H.msg(p, "Sem energia para voar!");
                    return;
                }
                H.msg(p, novo ? "Voo ATIVADO" : "Voo desativado");
                H.som(p, SoundEvents.ELYTRA_FLYING, 0.6f, 1.2f);
            } else {
                long fim = d.getLong("cd0");
                if (agora < fim && !Estado.semCd(p)) {
                    H.msg(p, "Recarregando: " + ((fim - agora) / 20 + 1) + "s");
                    return;
                }
                d.putLong("cd0", agora + 300);
                H.msg(p, "Sentidos aguçados!");
                H.sentidos(p);
            }
            return;
        }

        if (id < 1 || id > 3 || id > h.habs.length) return;
        long fim = d.getLong("cd" + id);
        if (agora < fim && !Estado.semCd(p)) {
            H.msg(p, "Recarregando: " + ((fim - agora) / 20 + 1) + "s");
            return;
        }
        if (Mec.tipo(h) == Mec.Tipo.CARGA && !Estado.semCd(p)) {
            int[] custo = {0, 80, 200, 350};
            if (Estado.energia(p) < custo[id]) {
                H.msg(p, "Sem carga! (" + Estado.energia(p) + "/" + custo[id] + ")");
                return;
            }
            Estado.addEnergia(p, -custo[id]);
        }
        Heroi.Hab hab = h.habs[id - 1];
        boolean canal = Cosmico.podeCanalizar(p, h);
        d.putLong("cd" + id, agora + (long) (hab.cd() * (canal ? 1.5 : 1.0)));
        H.msg(p, hab.nome() + (canal ? " CANALIZADO!" : "!"));
        try {
            hab.a().run(p);
            if (canal) Cosmico.eco(p, h, hab);
        } catch (Exception ignorado) {
        }
        Estado.sync(p);
    }

    /** Tecla G: alterna entre CONTIDO (não mata) e TOTAL (lutando com tudo). */
    private static void modo(ServerPlayer p) {
        Heroi h = atual(p);
        if (h == null) {
            H.msg(p, "Vista um traje de herói para usar o modo de força.");
            return;
        }
        if (!Estado.bom(h)) {
            H.msg(p, "Vilões não se contêm.");
            return;
        }
        boolean novo = !Estado.total(p);
        Estado.setTotal(p, novo);
        H.msg(p, novo ? "MODO TOTAL: lutando com tudo!" : "MODO CONTIDO: você se segura para não matar.");
        H.som(p, novo ? SoundEvents.LIGHTNING_BOLT_THUNDER : SoundEvents.AMETHYST_BLOCK_CHIME, 0.6f, novo ? 1.4f : 1.0f);
        if (novo) Efeitos.anel(p, 5, h.cor1, null);
        Estado.sync(p);
    }

    /** Tecla H: item na mão secundária > golpe máximo do traje > poder próprio. */
    private static void quarta(ServerPlayer p) {
        if (Acess.usar(p)) return;
        Heroi h = atual(p);
        if (h != null) {
            if (kryptonita(p, h)) {
                H.msg(p, "Kryptonita! Seus poderes falham.");
                return;
            }
            Mec.ultimo(p, h);
            Estado.sync(p);
            return;
        }
        if (PoderProprio.tem(p)) {
            PoderProprio.usar(p);
            return;
        }
        if (Cosmico.fragmento(p) > 0 || Cosmico.criador(p)) {
            Cosmico.usarFragmento(p);
            return;
        }
        H.msg(p, "Nada para usar: vista um traje, segure um item especial ou crie um poder (/poder).");
    }

    public static void aviso(ServerPlayer p, Heroi h) {
        p.sendSystemMessage(Component.literal("§6Traje de §f" + h.nome + " §6completo!"));
        p.sendSystemMessage(Component.literal("§7R = " + (h.voo > 0 ? "voar" : "sentidos")
                + " | V, B, N = habilidades | H = golpe máximo | G = modo contido/total"));
    }
}
