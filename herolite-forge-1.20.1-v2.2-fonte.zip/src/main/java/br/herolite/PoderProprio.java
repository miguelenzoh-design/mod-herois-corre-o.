package br.herolite;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Crie seu próprio poder: elemento + forma + força + passivo + cor. Evolui com o uso. */
public final class PoderProprio {
    private PoderProprio() {}

    public static final List<String> ELEMENTOS = List.of("fogo", "gelo", "raio", "veneno", "trevas", "luz", "vento", "terra");
    public static final List<String> FORMAS = List.of("raio", "explosao", "onda", "projetil", "aura");
    public static final List<String> PASSIVOS = List.of("velocidade", "forca", "resistencia", "regeneracao", "visao", "pulo", "antifogo", "nenhum");

    private static CompoundTag c(ServerPlayer p) {
        CompoundTag d = Herois.dados(p);
        if (!d.contains("meupoder", 10)) d.put("meupoder", new CompoundTag());
        return d.getCompound("meupoder");
    }

    public static boolean tem(ServerPlayer p) {
        return Herois.dados(p).contains("meupoder", 10) && c(p).getBoolean("criado");
    }

    // ---------- comandos ----------
    public static int cmdNovo(ServerPlayer p, String nome) {
        if (tem(p)) {
            H.msg(p, "Você já tem um poder. Use /poder apagar para recomeçar.");
            return 0;
        }
        if (!p.isCreative()) {
            boolean achou = false;
            for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
                ItemStack s = p.getInventory().getItem(i);
                if (s.is(HeroLite.CRISTAL.get())) {
                    s.shrink(1);
                    achou = true;
                    break;
                }
            }
            if (!achou) {
                H.msg(p, "Você precisa de um Cristal de Poder para despertar seu poder.");
                return 0;
            }
        }
        CompoundTag t = new CompoundTag();
        t.putBoolean("criado", true);
        t.putString("nome", nome);
        t.putString("elemento", "raio");
        t.putString("forma", "projetil");
        t.putString("passivo", "nenhum");
        t.putString("cor", "");
        t.putInt("forca", 3);
        t.putInt("xp", 0);
        Herois.dados(p).put("meupoder", t);
        H.msg(p, "Poder \"" + nome + "\" despertou! Configure com /poder elemento|forma|forca|passivo|cor. Use na tecla H.");
        return 1;
    }

    public static int cmdCampo(ServerPlayer p, String campo, String valor) {
        if (!tem(p)) {
            H.msg(p, "Crie um poder primeiro: /poder novo <nome>");
            return 0;
        }
        CompoundTag t = c(p);
        valor = valor.toLowerCase();
        switch (campo) {
            case "elemento" -> {
                if (!ELEMENTOS.contains(valor)) return erro(p, "Elementos: " + String.join(", ", ELEMENTOS));
                t.putString("elemento", valor);
            }
            case "forma" -> {
                if (!FORMAS.contains(valor)) return erro(p, "Formas: " + String.join(", ", FORMAS));
                t.putString("forma", valor);
            }
            case "passivo" -> {
                if (!PASSIVOS.contains(valor)) return erro(p, "Passivos: " + String.join(", ", PASSIVOS));
                t.putString("passivo", valor);
            }
            case "cor" -> {
                String h = valor.startsWith("#") ? valor.substring(1) : valor;
                try {
                    Integer.parseInt(h, 16);
                } catch (NumberFormatException ex) {
                    return erro(p, "Cor inválida. Use hex, ex: FF8800");
                }
                if (h.length() != 6) return erro(p, "Cor inválida. Use 6 dígitos hex, ex: FF8800");
                t.putString("cor", h);
            }
            case "forca" -> t.putInt("forca", Math.max(1, Math.min(10, Integer.parseInt(valor))));
            default -> {
                return 0;
            }
        }
        H.msg(p, "Poder atualizado: " + campo + " = " + valor);
        return 1;
    }

    private static int erro(ServerPlayer p, String s) {
        H.msg(p, s);
        return 0;
    }

    public static int cmdInfo(ServerPlayer p) {
        if (!tem(p)) {
            H.msg(p, "Você ainda não tem um poder. Use /poder novo <nome> (precisa de Cristal de Poder).");
            return 0;
        }
        CompoundTag t = c(p);
        p.sendSystemMessage(Component.literal("Poder: " + t.getString("nome") + " | " + t.getString("elemento") + " / " + t.getString("forma")
                + " | força " + t.getInt("forca") + " | nível " + nivel(t) + " (usos: " + t.getInt("xp") + ") | passivo: " + t.getString("passivo")));
        return 1;
    }

    public static int cmdApagar(ServerPlayer p) {
        Herois.dados(p).remove("meupoder");
        H.msg(p, "Poder apagado.");
        return 1;
    }

    // ---------- mecânica ----------
    static int nivel(CompoundTag t) {
        return Math.min(5, 1 + t.getInt("xp") / 25);
    }

    private static int corRgb(CompoundTag t) {
        String h = t.getString("cor");
        if (!h.isEmpty()) {
            try {
                return Integer.parseInt(h, 16);
            } catch (NumberFormatException ignorado) {
            }
        }
        return switch (t.getString("elemento")) {
            case "fogo" -> 0xFF6A10;
            case "gelo" -> 0x9FE8FF;
            case "raio" -> 0xFFF040;
            case "veneno" -> 0x70E030;
            case "trevas" -> 0x6020A0;
            case "luz" -> 0xFFFFC0;
            case "vento" -> 0xD8F0F0;
            default -> 0x9A7040;
        };
    }

    private static ParticleOptions part(String el) {
        return switch (el) {
            case "fogo" -> ParticleTypes.FLAME;
            case "gelo" -> ParticleTypes.SNOWFLAKE;
            case "raio" -> ParticleTypes.ELECTRIC_SPARK;
            case "veneno" -> ParticleTypes.SPORE_BLOSSOM_AIR;
            case "trevas" -> ParticleTypes.SMOKE;
            case "luz" -> ParticleTypes.END_ROD;
            case "vento" -> ParticleTypes.CLOUD;
            default -> ParticleTypes.CRIT;
        };
    }

    private static void aplicar(ServerPlayer p, LivingEntity a, String el, int forca) {
        int seg = 2 + forca / 2;
        switch (el) {
            case "fogo" -> a.setSecondsOnFire(seg);
            case "gelo" -> H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, seg, 2);
            case "raio" -> {
                H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, 1 + forca / 4, 5);
                Efeitos.arco(p.serverLevel(), p.getEyePosition(), a.position().add(0, a.getBbHeight() / 2, 0), 0xFFF040);
            }
            case "veneno" -> H.efeito(a, MobEffects.POISON, seg, 1);
            case "trevas" -> {
                H.efeito(a, MobEffects.BLINDNESS, seg, 0);
                H.efeito(a, MobEffects.WEAKNESS, seg, 1);
            }
            case "luz" -> {
                H.efeito(a, MobEffects.GLOWING, seg, 0);
                H.curar(p, 1f);
            }
            case "vento" -> H.empurrar(p, a, 0.8 + forca * 0.15);
            default -> {
                H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, seg, 1);
                a.setDeltaMovement(a.getDeltaMovement().add(0, 0.5, 0));
                a.hurtMarked = true;
            }
        }
    }

    public static void usar(ServerPlayer p) {
        if (!tem(p)) return;
        CompoundTag t = c(p);
        long agora = p.level().getGameTime();
        long fim = Herois.dados(p).getLong("pcd");
        if (agora < fim && !Estado.semCd(p)) {
            H.msg(p, "Recarregando: " + ((fim - agora) / 20 + 1) + "s");
            return;
        }
        int forca = t.getInt("forca");
        int nv = nivel(t);
        String el = t.getString("elemento");
        String forma = t.getString("forma");
        int cor = corRgb(t);
        float dano = (3f + forca * 1.3f) * (1f + 0.12f * (nv - 1));
        Herois.dados(p).putLong("pcd", agora + Math.max(40, 50 + forca * 14 - nv * 8));
        t.putInt("xp", t.getInt("xp") + 1);
        H.msg(p, t.getString("nome") + "!");
        var w = p.serverLevel();
        ParticleOptions pt = part(el);
        switch (forma) {
            case "raio" -> {
                Efeitos.feixe(p, 20 + forca * 3, 20 + forca * 2, dano * 0.5f, cor, 0xFFFFFF, el.equals("fogo"), 1.2f + forca * 0.06f);
            }
            case "explosao" -> {
                LivingEntity a = H.alvo(p, 30 + forca * 2);
                Vec3 ponto = a != null ? a.position() : H.fim(p, 30 + forca * 2);
                H.raio(p, 30 + forca * 2, pt);
                Efeitos.explosaoVisual(w, ponto, cor, 2f + forca * 0.4f);
                AABBHelper.dano(p, ponto, 2.5 + forca * 0.4, dano, el, forca);
            }
            case "onda" -> {
                Efeitos.anel(p, 4 + forca * 0.7, cor, pt);
                for (LivingEntity a : H.area(p, 4 + forca * 0.7)) {
                    if (H.dano(p, a, dano)) aplicar(p, a, el, forca);
                }
            }
            case "aura" -> {
                for (int i = 0; i < 6; i++) {
                    H.agendar(i * 10L, () -> {
                        if (p.isRemoved() || !p.isAlive()) return;
                        Efeitos.anel(p, 3.5, cor, pt);
                        for (LivingEntity a : H.area(p, 3.5)) {
                            if (H.dano(p, a, dano * 0.4f)) aplicar(p, a, el, forca);
                        }
                    });
                }
            }
            default -> {
                LivingEntity a = H.tiro(p, 28 + forca * 2, dano, pt);
                if (a != null) aplicar(p, a, el, forca);
            }
        }
        H.som(p, SoundEvents.FIRECHARGE_USE, 1f, 1.1f);
        if (t.getInt("xp") % 25 == 0) H.msg(p, "Seu poder evoluiu para o nível " + nivel(t) + "!");
    }

    /** Passivo escolhido. */
    public static void tick(ServerPlayer p) {
        if (!tem(p)) return;
        CompoundTag t = c(p);
        int nv = nivel(t);
        int amp = nv >= 4 ? 1 : 0;
        switch (t.getString("passivo")) {
            case "velocidade" -> H.efeito(p, MobEffects.MOVEMENT_SPEED, 3, amp);
            case "forca" -> H.efeito(p, MobEffects.DAMAGE_BOOST, 3, amp);
            case "resistencia" -> H.efeito(p, MobEffects.DAMAGE_RESISTANCE, 3, amp);
            case "regeneracao" -> H.efeito(p, MobEffects.REGENERATION, 3, amp);
            case "visao" -> H.efeito(p, MobEffects.NIGHT_VISION, 14, 0);
            case "pulo" -> H.efeito(p, MobEffects.JUMP, 3, amp + 1);
            case "antifogo" -> H.efeito(p, MobEffects.FIRE_RESISTANCE, 3, 0);
            default -> {
            }
        }
    }

    /** Ajuda: dano em área num ponto. */
    private static final class AABBHelper {
        static void dano(ServerPlayer p, Vec3 c, double r, float d, String el, int forca) {
            var box = new net.minecraft.world.phys.AABB(c, c).inflate(r);
            List<LivingEntity> l = p.level().getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive());
            int n = 0;
            for (LivingEntity a : l) {
                if (n++ >= 15) break;
                if (H.dano(p, a, d)) aplicar(p, a, el, forca);
            }
        }
    }
}
