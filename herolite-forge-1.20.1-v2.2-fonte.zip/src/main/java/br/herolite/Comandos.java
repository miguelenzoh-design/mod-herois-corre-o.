package br.herolite;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = HeroLite.ID)
public final class Comandos {
    private Comandos() {}

    private static final String[] UNI = {"Marvel (heróis)", "DC (heróis)", "Marvel (vilões)", "DC (vilões)", "Entidades Cósmicas"};

    @SubscribeEvent
    public static void registrar(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("heroi").requires(s -> s.hasPermission(2))
                .then(Commands.literal("dar")
                        .then(Commands.argument("heroi", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(Heroi.ids(), b))
                                .executes(c -> dar(c.getSource(), c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "heroi")))
                                .then(Commands.argument("jogador", EntityArgument.player())
                                        .executes(c -> dar(c.getSource(), EntityArgument.getPlayer(c, "jogador"), StringArgumentType.getString(c, "heroi"))))))
                .then(Commands.literal("kit").executes(c -> kit(c.getSource(), c.getSource().getPlayerOrException())))
                .then(Commands.literal("lista").executes(c -> lista(c.getSource(), -1))
                        .then(Commands.argument("universo", IntegerArgumentType.integer(0, 4))
                                .executes(c -> lista(c.getSource(), IntegerArgumentType.getInteger(c, "universo")))))
                .then(Commands.literal("cooldown")
                        .then(Commands.literal("reset").executes(c -> cdReset(c.getSource(), c.getSource().getPlayerOrException())))
                        .then(Commands.literal("off").executes(c -> cdOff(c.getSource(), c.getSource().getPlayerOrException(), true)))
                        .then(Commands.literal("on").executes(c -> cdOff(c.getSource(), c.getSource().getPlayerOrException(), false))))
                .then(Commands.literal("energia")
                        .then(Commands.literal("max").executes(c -> energia(c.getSource(), Estado.MAX)))
                        .then(Commands.argument("valor", IntegerArgumentType.integer(0, Estado.MAX))
                                .executes(c -> energia(c.getSource(), IntegerArgumentType.getInteger(c, "valor")))))
                .then(Commands.literal("modo")
                        .then(Commands.literal("contido").executes(c -> modo(c.getSource(), false)))
                        .then(Commands.literal("total").executes(c -> modo(c.getSource(), true))))
                .then(Commands.literal("poder")
                        .then(Commands.argument("mult", FloatArgumentType.floatArg(0.1f, 20f))
                                .executes(c -> poder(c.getSource(), FloatArgumentType.getFloat(c, "mult")))))
                .then(Commands.literal("voo")
                        .then(Commands.argument("on", BoolArgumentType.bool())
                                .executes(c -> voo(c.getSource(), BoolArgumentType.getBool(c, "on")))))
                .then(Commands.literal("curar").executes(c -> curar(c.getSource())))
                .then(Commands.literal("deus")
                        .then(Commands.argument("on", BoolArgumentType.bool())
                                .executes(c -> deus(c.getSource(), BoolArgumentType.getBool(c, "on")))))
                .then(Commands.literal("resetar").executes(c -> resetar(c.getSource())))
                .then(Commands.literal("mob")
                        .then(Commands.argument("tipo", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(Mobs.nomes(), b))
                                .executes(c -> mob(c.getSource(), StringArgumentType.getString(c, "tipo"))))));

        d.register(Commands.literal("poder").requires(s -> s.hasPermission(0))
                .then(Commands.literal("novo")
                        .then(Commands.argument("nome", StringArgumentType.word())
                                .executes(c -> PoderProprio.cmdNovo(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "nome")))))
                .then(Commands.literal("elemento")
                        .then(Commands.argument("valor", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(PoderProprio.ELEMENTOS, b))
                                .executes(c -> PoderProprio.cmdCampo(c.getSource().getPlayerOrException(), "elemento", StringArgumentType.getString(c, "valor")))))
                .then(Commands.literal("forma")
                        .then(Commands.argument("valor", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(PoderProprio.FORMAS, b))
                                .executes(c -> PoderProprio.cmdCampo(c.getSource().getPlayerOrException(), "forma", StringArgumentType.getString(c, "valor")))))
                .then(Commands.literal("passivo")
                        .then(Commands.argument("valor", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(PoderProprio.PASSIVOS, b))
                                .executes(c -> PoderProprio.cmdCampo(c.getSource().getPlayerOrException(), "passivo", StringArgumentType.getString(c, "valor")))))
                .then(Commands.literal("cor")
                        .then(Commands.argument("hex", StringArgumentType.word())
                                .executes(c -> PoderProprio.cmdCampo(c.getSource().getPlayerOrException(), "cor", StringArgumentType.getString(c, "hex")))))
                .then(Commands.literal("forca")
                        .then(Commands.argument("n", IntegerArgumentType.integer(1, 10))
                                .executes(c -> PoderProprio.cmdCampo(c.getSource().getPlayerOrException(), "forca", String.valueOf(IntegerArgumentType.getInteger(c, "n"))))))
                .then(Commands.literal("usar").executes(c -> { PoderProprio.usar(c.getSource().getPlayerOrException()); return 1; }))
                .then(Commands.literal("info").executes(c -> PoderProprio.cmdInfo(c.getSource().getPlayerOrException())))
                .then(Commands.literal("apagar").executes(c -> PoderProprio.cmdApagar(c.getSource().getPlayerOrException()))));
    }

    private static void ok(CommandSourceStack s, String t) {
        s.sendSuccess(() -> Component.literal(t), false);
    }

    private static int dar(CommandSourceStack s, ServerPlayer p, String id) {
        Heroi h = Heroi.de(id);
        if (h == null) {
            s.sendFailure(Component.literal("Herói desconhecido: " + id));
            return 0;
        }
        for (ArmorItem.Type t : ArmorItem.Type.values()) {
            Item it = HeroLite.PECAS.get(h.id + "_" + HeroLite.sufixo(t)).get();
            darItem(p, new ItemStack(it));
        }
        ok(s, "Traje de " + h.nome + " entregue a " + p.getName().getString());
        return 1;
    }

    static void darItem(ServerPlayer p, ItemStack st) {
        if (!p.getInventory().add(st)) p.drop(st, false);
    }

    private static int kit(CommandSourceStack s, ServerPlayer p) {
        for (var o : HeroLite.ITEMS.getEntries()) {
            String n = o.getId().getPath();
            if (n.endsWith("_helmet") || n.endsWith("_chestplate") || n.endsWith("_leggings") || n.endsWith("_boots") || n.endsWith("_emblem")) continue;
            if (n.endsWith("_spawn_egg")) continue;
            darItem(p, new ItemStack(o.get()));
        }
        ok(s, "Kit de itens especiais entregue.");
        return 1;
    }

    private static int lista(CommandSourceStack s, int uni) {
        for (int u = 0; u < 5; u++) {
            if (uni >= 0 && uni != u) continue;
            List<String> l = new ArrayList<>();
            for (Heroi h : Heroi.values()) if (h.universo == u) l.add(h.id);
            ok(s, UNI[u] + " (" + l.size() + "): " + String.join(", ", l));
        }
        return 1;
    }

    private static int cdReset(CommandSourceStack s, ServerPlayer p) {
        CompoundTag d = Herois.dados(p);
        for (int i = 0; i <= 4; i++) d.putLong("cd" + i, 0L);
        ok(s, "Cooldowns zerados.");
        return 1;
    }

    private static int cdOff(CommandSourceStack s, ServerPlayer p, boolean off) {
        Herois.dados(p).putBoolean("semcd", off);
        if (off) cdReset(s, p);
        ok(s, off ? "Sem cooldown: ATIVADO." : "Sem cooldown: desativado.");
        return 1;
    }

    private static int energia(CommandSourceStack s, int v) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        Estado.setEnergia(p, v);
        Estado.sync(p);
        ok(s, "Energia do traje: " + v + "/" + Estado.MAX);
        return 1;
    }

    private static int modo(CommandSourceStack s, boolean total) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        Estado.setTotal(p, total);
        Estado.sync(p);
        ok(s, total ? "Modo TOTAL: lutando com tudo." : "Modo CONTIDO: segurando a força.");
        return 1;
    }

    private static int poder(CommandSourceStack s, float m) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        Herois.dados(s.getPlayerOrException()).putFloat("multcmd", m);
        ok(s, "Multiplicador de poder: x" + m);
        return 1;
    }

    private static int voo(CommandSourceStack s, boolean on) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        Herois.dados(p).putBoolean("voo_livre", on);
        p.getAbilities().mayfly = on || p.isCreative();
        if (!on && !p.isCreative()) p.getAbilities().flying = false;
        p.onUpdateAbilities();
        ok(s, "Voo livre: " + (on ? "ligado" : "desligado"));
        return 1;
    }

    private static int curar(CommandSourceStack s) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        p.setHealth(p.getMaxHealth());
        p.getFoodData().setFoodLevel(20);
        p.getFoodData().setSaturation(20f);
        p.removeAllEffects();
        p.clearFire();
        ok(s, "Curado.");
        return 1;
    }

    private static int deus(CommandSourceStack s, boolean on) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        p.getAbilities().invulnerable = on || p.isCreative();
        p.onUpdateAbilities();
        ok(s, "Invulnerável: " + (on ? "ligado" : "desligado"));
        return 1;
    }

    private static int resetar(CommandSourceStack s) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        CompoundTag d = Herois.dados(p);
        for (int i = 0; i <= 4; i++) d.putLong("cd" + i, 0L);
        d.putBoolean("semcd", false);
        d.putBoolean("total", false);
        d.putFloat("multcmd", 1f);
        Estado.setEnergia(p, 0);
        p.getAbilities().invulnerable = p.isCreative();
        p.onUpdateAbilities();
        Estado.sync(p);
        ok(s, "Estado de herói resetado.");
        return 1;
    }

    private static int mob(CommandSourceStack s, String tipo) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        if (!Mobs.invocar(p.serverLevel(), tipo, p.position().add(p.getLookAngle().scale(5)))) {
            s.sendFailure(Component.literal("Tipo desconhecido: " + tipo));
            return 0;
        }
        ok(s, "Invocado: " + tipo);
        return 1;
    }
}
