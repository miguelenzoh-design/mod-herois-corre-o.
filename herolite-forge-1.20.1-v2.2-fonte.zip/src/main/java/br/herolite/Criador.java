package br.herolite;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Comandos /cosmico (fragmentos de poder) e /criador (exclusivos do dono do mod), mais os eventos do sistema cósmico. */
@Mod.EventBusSubscriber(modid = HeroLite.ID)
public final class Criador {
    private Criador() {}

    // ---------- dono do mod ----------
    private static Path arquivo() {
        return FMLPaths.GAMEDIR.get().resolve("herolite_criador.txt");
    }

    static List<String> donos() {
        try {
            Path f = arquivo();
            if (!Files.exists(f)) return new ArrayList<>();
            List<String> l = new ArrayList<>();
            for (String s : Files.readAllLines(f, StandardCharsets.UTF_8)) {
                if (!s.isBlank()) l.add(s.trim().toLowerCase(Locale.ROOT));
            }
            return l;
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    private static void salvar(List<String> l) throws IOException {
        Files.write(arquivo(), l, StandardCharsets.UTF_8);
    }

    static boolean dono(CommandSourceStack s) {
        if (!(s.getEntity() instanceof ServerPlayer p)) return false;
        return donos().contains(p.getGameProfile().getName().toLowerCase(Locale.ROOT));
    }

    private static boolean donoOuMsg(CommandSourceStack s) {
        if (dono(s)) return true;
        s.sendFailure(Component.literal("Só o Criador do mod pode usar isso. Use /criador registrar se ainda não há um Criador."));
        return false;
    }

    // ---------- registro dos comandos ----------
    @SubscribeEvent
    public static void comandos(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();

        d.register(Commands.literal("cosmico").requires(s -> s.hasPermission(2))
                .then(Commands.literal("conceder")
                        .then(Commands.argument("alvos", EntityArgument.entities())
                                .executes(c -> conceder(c.getSource(), EntityArgument.getEntities(c, "alvos"), 20, false))
                                .then(Commands.argument("parcela", IntegerArgumentType.integer(1, 100))
                                        .executes(c -> conceder(c.getSource(), EntityArgument.getEntities(c, "alvos"),
                                                IntegerArgumentType.getInteger(c, "parcela"), false)))))
                .then(Commands.literal("dar")
                        .then(Commands.argument("alvos", EntityArgument.entities())
                                .then(Commands.argument("parcela", IntegerArgumentType.integer(1, 100))
                                        .executes(c -> conceder(c.getSource(), EntityArgument.getEntities(c, "alvos"),
                                                IntegerArgumentType.getInteger(c, "parcela"), true)))))
                .then(Commands.literal("retirar")
                        .then(Commands.argument("alvos", EntityArgument.entities())
                                .executes(c -> retirar(c.getSource(), EntityArgument.getEntities(c, "alvos")))))
                .then(Commands.literal("retirar-tudo").executes(c -> {
                    Cosmico.retirarTudo();
                    return ok(c.getSource(), "Todos os fragmentos foram retirados.");
                }))
                .then(Commands.literal("info")
                        .then(Commands.argument("alvo", EntityArgument.entity())
                                .executes(c -> info(c.getSource(), EntityArgument.getEntity(c, "alvo")))))
                .then(Commands.literal("lista").executes(c -> lista(c.getSource()))));

        d.register(Commands.literal("criador").requires(s -> s.hasPermission(2))
                .then(Commands.literal("registrar").executes(c -> registrar(c.getSource())))
                .then(Commands.literal("adicionar")
                        .then(Commands.argument("nick", StringArgumentType.word())
                                .executes(c -> adicionar(c.getSource(), StringArgumentType.getString(c, "nick")))))
                .then(Commands.literal("poder")
                        .executes(c -> poder(c.getSource(), null))
                        .then(Commands.argument("on", BoolArgumentType.bool())
                                .executes(c -> poder(c.getSource(), BoolArgumentType.getBool(c, "on")))))
                .then(Commands.literal("mult")
                        .then(Commands.argument("x", FloatArgumentType.floatArg(1f, 1000f))
                                .executes(c -> mult(c.getSource(), FloatArgumentType.getFloat(c, "x")))))
                .then(Commands.literal("kit").executes(c -> kit(c.getSource())))
                .then(Commands.literal("apagar")
                        .then(Commands.argument("alvos", EntityArgument.entities())
                                .executes(c -> apagar(c.getSource(), EntityArgument.getEntities(c, "alvos")))))
                .then(Commands.literal("vida")
                        .then(Commands.argument("alvos", EntityArgument.entities())
                                .then(Commands.argument("n", FloatArgumentType.floatArg(1f, 100000f))
                                        .executes(c -> vida(c.getSource(), EntityArgument.getEntities(c, "alvos"), FloatArgumentType.getFloat(c, "n"))))))
                .then(Commands.literal("curar").executes(c -> curar(c.getSource())))
                .then(Commands.literal("status").executes(c -> status(c.getSource()))));
    }

    private static int ok(CommandSourceStack s, String t) {
        s.sendSuccess(() -> Component.literal(t), false);
        return 1;
    }

    // ---------- /cosmico ----------
    private static int conceder(CommandSourceStack s, java.util.Collection<? extends Entity> alvos, int parcela, boolean livre) throws CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        int n = 0;
        for (Entity e : alvos) {
            if (!(e instanceof LivingEntity a)) continue;
            String r = Cosmico.conceder(p, a, parcela, livre);
            ok(s, r);
            n++;
        }
        return n;
    }

    private static int retirar(CommandSourceStack s, java.util.Collection<? extends Entity> alvos) {
        ServerPlayer p = s.getEntity() instanceof ServerPlayer sp ? sp : null;
        boolean admin = p == null;
        int n = 0;
        for (Entity e : alvos) {
            if (!(e instanceof LivingEntity a)) continue;
            ok(s, Cosmico.retirar(a, p, admin));
            n++;
        }
        return n;
    }

    private static int info(CommandSourceStack s, Entity e) {
        if (!(e instanceof LivingEntity a)) return 0;
        CompoundTag n = Cosmico.nbt(a);
        return ok(s, a.getName().getString() + ": fragmento " + n.getInt("cosmo_frag") + "%"
                + (Cosmico.criador(a) ? " (CRIADOR)" : ""));
    }

    private static int lista(CommandSourceStack s) {
        List<LivingEntity> l = Cosmico.portadores();
        if (l.isEmpty()) return ok(s, "Ninguém tem fragmento cósmico agora.");
        for (LivingEntity a : l) ok(s, "- " + a.getName().getString() + ": " + Cosmico.fragmento(a) + "%");
        return l.size();
    }

    // ---------- /criador ----------
    private static int registrar(CommandSourceStack s) throws CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        List<String> l = donos();
        if (!l.isEmpty()) return ok(s, "Já existe um Criador registrado.");
        l.add(p.getGameProfile().getName().toLowerCase(Locale.ROOT));
        try {
            salvar(l);
        } catch (IOException ex) {
            s.sendFailure(Component.literal("Não consegui salvar herolite_criador.txt"));
            return 0;
        }
        return ok(s, "§6Você agora é o CRIADOR do Hero Lite. Use /criador poder para se tornar o mais poderoso.");
    }

    private static int adicionar(CommandSourceStack s, String nick) {
        if (!donoOuMsg(s)) return 0;
        List<String> l = donos();
        l.add(nick.toLowerCase(Locale.ROOT));
        try {
            salvar(l);
        } catch (IOException ex) {
            return 0;
        }
        return ok(s, nick + " agora também é Criador.");
    }

    private static int poder(CommandSourceStack s, Boolean on) throws CommandSyntaxException {
        if (!donoOuMsg(s)) return 0;
        ServerPlayer p = s.getPlayerOrException();
        CompoundTag d = Herois.dados(p);
        boolean novo = on != null ? on : !d.getBoolean("criador");
        d.putBoolean("criador", novo);
        d.putBoolean("semcd", novo);
        d.putFloat("multcmd", novo ? 25f : 1f);
        if (novo) {
            Estado.setEnergia(p, Estado.MAX);
            p.setHealth(p.getMaxHealth());
            H.faisca(p, net.minecraft.core.particles.ParticleTypes.END_ROD, 40);
            return ok(s, "§6PODER DO CRIADOR ATIVO: invulnerável, imortal, voo, sem recarga, dano x25, energia infinita.");
        }
        return ok(s, "§7Poder do Criador desativado.");
    }

    private static int mult(CommandSourceStack s, float x) throws CommandSyntaxException {
        if (!donoOuMsg(s)) return 0;
        Herois.dados(s.getPlayerOrException()).putFloat("multcmd", x);
        return ok(s, "Multiplicador do Criador: x" + x);
    }

    private static int kit(CommandSourceStack s) throws CommandSyntaxException {
        if (!donoOuMsg(s)) return 0;
        ServerPlayer p = s.getPlayerOrException();
        ItemStack[] itens = {new ItemStack(HeroLite.CORACAO.get()), new ItemStack(HeroLite.CANALIZADOR.get()),
                new ItemStack(HeroLite.CETRO.get()), new ItemStack(HeroLite.FRAGMENTO.get(), 8)};
        for (ItemStack st : itens) if (!p.getInventory().add(st)) p.drop(st, false);
        return ok(s, "Kit cósmico entregue (use /heroi dar <traje> para os trajes: superman_cosmic, phoenix, morte, presenca, galactus, eternidade, tribunal, anti_monitor, spectre).");
    }

    private static int apagar(CommandSourceStack s, java.util.Collection<? extends Entity> alvos) {
        if (!donoOuMsg(s)) return 0;
        int n = 0;
        for (Entity e : alvos) {
            if (e == s.getEntity()) continue;
            if (e instanceof ServerPlayer sp) {
                if (Cosmico.criador(sp)) continue;
                sp.hurt(sp.damageSources().genericKill(), Float.MAX_VALUE);
            } else {
                e.discard();
            }
            n++;
        }
        return ok(s, n + " entidade(s) apagada(s).");
    }

    private static int vida(CommandSourceStack s, java.util.Collection<? extends Entity> alvos, float v) {
        if (!donoOuMsg(s)) return 0;
        int n = 0;
        for (Entity e : alvos) {
            if (e instanceof LivingEntity a && a.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH) != null) {
                a.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH).setBaseValue(v);
                a.setHealth(v);
                n++;
            }
        }
        return ok(s, "Vida máxima ajustada em " + n + " entidade(s).");
    }

    private static int curar(CommandSourceStack s) throws CommandSyntaxException {
        if (!donoOuMsg(s)) return 0;
        ServerPlayer p = s.getPlayerOrException();
        p.setHealth(p.getMaxHealth());
        p.getFoodData().setFoodLevel(20);
        return ok(s, "Curado.");
    }

    private static int status(CommandSourceStack s) throws CommandSyntaxException {
        ServerPlayer p = s.getPlayerOrException();
        return ok(s, "Criador registrado: " + (donos().isEmpty() ? "ninguém" : String.join(", ", donos()))
                + " | você é Criador: " + dono(s) + " | poder ativo: " + Cosmico.criador(p)
                + " | fragmento: " + Cosmico.fragmento(p) + "% | distribuído: " + Cosmico.dado(p) + "/" + Cosmico.reserva(p));
    }

    // ---------- eventos do sistema cósmico ----------
    @SubscribeEvent
    public static void tickServidor(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (e.getServer().getTickCount() % 20 != 0) return;
        try {
            Cosmico.tickGlobal(e.getServer());
        } catch (Exception ignorado) {
        }
    }

    @SubscribeEvent
    public static void entrou(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || !(e.getEntity() instanceof LivingEntity a)) return;
        if (Cosmico.fragmento(a) > 0) Cosmico.registrar(a);
    }

    /** O Criador é invulnerável (só /kill e o vazio... nem o vazio) e imortal. */
    @SubscribeEvent
    public static void ataque(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !Cosmico.criador(p)) return;
        DamageSource src = e.getSource();
        boolean enzo = Enzo.ativo(p);
        if (src.is(DamageTypes.GENERIC_KILL) && !enzo) return;
        if (enzo) Enzo.defender(p, src, e.getAmount());
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void morte(LivingDeathEvent e) {
        LivingEntity v = e.getEntity();
        if (v instanceof ServerPlayer p && Cosmico.criador(p) && (Enzo.ativo(p) || !e.getSource().is(DamageTypes.GENERIC_KILL))) {
            e.setCanceled(true);
            p.setHealth(p.getMaxHealth());
            p.clearFire();
            return;
        }
        // quem morre perde o fragmento (volta para o doador)
        if (Cosmico.fragmento(v) > 0) {
            Cosmico.limpar(v, false);
        }
    }

    @SubscribeEvent
    public static void dano(LivingHurtEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer p && Cosmico.criador(p) && !H.interno
                && e.getSource().getDirectEntity() == p && Herois.atual(p) == null) {
            e.setAmount(e.getAmount() * 30f);
        }
    }

    @SubscribeEvent
    public static void parando(ServerStoppingEvent e) {
        Cosmico.limparLista();
    }
}
