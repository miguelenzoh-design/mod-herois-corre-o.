package br.herolite;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Funções auxiliares: tudo é hitscan + partículas (sem entidades próprias = leve). */
public final class H {
    private record Tarefa(long quando, Runnable r) {}

    private static final List<Tarefa> TAREFAS = new ArrayList<>();
    static long agora = 0;

    private H() {}

    // ---------- agenda ----------
    static void agendar(long atraso, Runnable r) {
        TAREFAS.add(new Tarefa(agora + atraso, r));
    }

    static void rodar() {
        agora++;
        if (TAREFAS.isEmpty()) return;
        List<Tarefa> prontas = null;
        for (Tarefa t : TAREFAS) {
            if (t.quando() <= agora) {
                if (prontas == null) prontas = new ArrayList<>();
                prontas.add(t);
            }
        }
        if (prontas == null) return;
        TAREFAS.removeAll(prontas);
        for (Tarefa t : prontas) {
            try {
                t.r().run();
            } catch (Exception ignorado) {
            }
        }
    }

    static void limparAgenda() {
        TAREFAS.clear();
    }

    // ---------- construtores de dados ----------
    static Heroi.Pass P(MobEffect e, int a) {
        return new Heroi.Pass(e, a);
    }

    static Heroi.Pass[] ps(Heroi.Pass... x) {
        return x;
    }

    static Heroi.Hab h(String n, int cd, Heroi.Acao a) {
        return new Heroi.Hab(n, cd, a);
    }

    // ---------- mensagens e sons ----------
    static void msg(ServerPlayer p, String s) {
        p.displayClientMessage(Component.literal(s), true);
    }

    static void som(ServerPlayer p, SoundEvent s, float v, float pt) {
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundSource.PLAYERS, v, pt);
    }

    // ---------- pontaria ----------
    static Vec3 fim(ServerPlayer p, double alc) {
        Vec3 a = p.getEyePosition();
        Vec3 b = a.add(p.getLookAngle().scale(alc));
        BlockHitResult r = p.serverLevel().clip(new ClipContext(a, b, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return r.getType() == HitResult.Type.MISS ? b : r.getLocation();
    }

    static LivingEntity alvo(ServerPlayer p, double alc) {
        Vec3 a = p.getEyePosition();
        Vec3 b = fim(p, alc);
        AABB box = p.getBoundingBox().expandTowards(b.subtract(a)).inflate(1.0);
        EntityHitResult r = ProjectileUtil.getEntityHitResult(p, a, b, box,
                e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e != p, alc * alc);
        return r == null ? null : (LivingEntity) r.getEntity();
    }

    /** true enquanto uma habilidade causa dano (o evento de dano não multiplica de novo). */
    static boolean interno = false;

    static boolean dano(ServerPlayer p, LivingEntity a, float d) {
        d *= Estado.multDano(p);
        if (Estado.total(p) && Estado.bom(Herois.atual(p)) && a.getMaxHealth() >= 100f) d *= 1.8f;
        if (Estado.contido(p)) {
            float max = a.getHealth() - 1f;
            if (max <= 0f) return false;
            d = Math.min(d, max);
        }
        interno = true;
        try {
            return a.hurt(p.level().damageSources().playerAttack(p), d);
        } finally {
            interno = false;
        }
    }

    /** Entidades atravessadas por um feixe de a até b (máx. 10). */
    static List<LivingEntity> naLinha(ServerPlayer p, Vec3 a, Vec3 b, double raio) {
        AABB box = new AABB(a, b).inflate(raio + 1);
        List<LivingEntity> todos = p.level().getEntitiesOfClass(LivingEntity.class, box,
                e -> e != p && e.isAlive() && !e.isSpectator());
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : todos) {
            if (e.getBoundingBox().inflate(raio).clip(a, b).isPresent()) out.add(e);
            if (out.size() >= 10) break;
        }
        return out;
    }

    static List<LivingEntity> area(ServerPlayer p, double r) {
        List<LivingEntity> l = p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                e -> e != p && e.isAlive() && !e.isSpectator() && e.distanceToSqr(p) <= r * r);
        return l.size() > 20 ? new ArrayList<>(l.subList(0, 20)) : l;
    }

    static List<LivingEntity> frente(ServerPlayer p, double r, double cos) {
        List<LivingEntity> out = new ArrayList<>();
        Vec3 look = p.getLookAngle();
        for (LivingEntity a : area(p, r)) {
            Vec3 v = a.position().subtract(p.position()).normalize();
            if (v.dot(look) >= cos) out.add(a);
        }
        return out;
    }

    // ---------- partículas ----------
    static void faisca(LivingEntity a, ParticleOptions t, int n) {
        if (a.level() instanceof ServerLevel w) {
            w.sendParticles(t, a.getX(), a.getY() + a.getBbHeight() * 0.5, a.getZ(), n, 0.3, 0.3, 0.3, 0.05);
        }
    }

    static void raio(ServerPlayer p, double alc, ParticleOptions t) {
        ServerLevel w = p.serverLevel();
        Heroi h = Herois.atual(p);
        int c1 = h != null ? h.cor1 : 0xFFFFFF;
        int c2 = h != null ? h.cor2 : 0xFFFFFF;
        Vec3 a = p.getEyePosition().add(0, -0.2, 0);
        Vec3 b = fim(p, alc);
        Efeitos.linha(w, a, b, c1, 1.5f, 2.0);
        Efeitos.linha(w, a, b, c2, 0.8f, 1.0);
        Vec3 d = b.subtract(a);
        int n = (int) Math.min(d.length(), 32);
        Vec3 u = d.lengthSqr() < 1e-6 ? d : d.normalize();
        for (int i = 2; i <= n; i += 3) {
            Vec3 c = a.add(u.scale(i));
            w.sendParticles(t, c.x, c.y, c.z, 1, 0.05, 0.05, 0.05, 0.01);
        }
    }

    static void nuvem(ServerPlayer p, ParticleOptions t, int n) {
        p.serverLevel().sendParticles(t, p.getX(), p.getY() + 1.0, p.getZ(), n, 2.0, 0.5, 2.0, 0.05);
    }

    // ---------- ataques ----------
    static LivingEntity tiro(ServerPlayer p, double alc, float d, ParticleOptions t) {
        raio(p, alc, t);
        LivingEntity a = alvo(p, alc);
        if (a == null) {
            msg(p, "Errou!");
            return null;
        }
        dano(p, a, d);
        faisca(a, t, 8);
        return a;
    }

    static LivingEntity golpe(ServerPlayer p, double alc, float d, double emp) {
        LivingEntity a = alvo(p, alc);
        if (a == null) {
            msg(p, "Sem alvo ao alcance");
            return null;
        }
        dano(p, a, d);
        if (emp > 0) empurrar(p, a, emp);
        faisca(a, ParticleTypes.CRIT, 8);
        som(p, SoundEvents.PLAYER_ATTACK_STRONG, 1.0f, 0.9f);
        return a;
    }

    static void barragem(ServerPlayer p, int hits, int inter, float d, double alc, String grito) {
        msg(p, grito);
        for (int i = 0; i < hits; i++) {
            agendar((long) i * inter, () -> {
                if (p.isRemoved() || !p.isAlive()) return;
                LivingEntity a = alvo(p, alc);
                if (a == null) return;
                a.invulnerableTime = 0;
                dano(p, a, d);
                faisca(a, ParticleTypes.CRIT, 3);
                som(p, SoundEvents.PLAYER_ATTACK_STRONG, 0.6f, 1.0f + (float) (Math.random() * 0.4));
            });
        }
    }

    static void ricochete(ServerPlayer p, double alc, float d) {
        raio(p, alc, ParticleTypes.CRIT);
        LivingEntity a = alvo(p, alc);
        if (a == null) {
            msg(p, "Errou!");
            return;
        }
        dano(p, a, d);
        faisca(a, ParticleTypes.CRIT, 8);
        List<LivingEntity> l = a.level().getEntitiesOfClass(LivingEntity.class, a.getBoundingBox().inflate(8),
                e -> e != p && e != a && e.isAlive());
        LivingEntity melhor = null;
        double md = Double.MAX_VALUE;
        for (LivingEntity e : l) {
            double q = e.distanceToSqr(a);
            if (q < md) {
                md = q;
                melhor = e;
            }
        }
        if (melhor != null) {
            final LivingEntity b = melhor;
            agendar(4, () -> {
                if (!b.isRemoved()) {
                    dano(p, b, d * 0.7f);
                    faisca(b, ParticleTypes.CRIT, 6);
                }
            });
        }
    }

    static void onda(ServerPlayer p, double r, float d, double f, ParticleOptions t) {
        nuvem(p, t, 30);
        for (LivingEntity a : area(p, r)) {
            dano(p, a, d);
            Vec3 v = a.position().subtract(p.position()).normalize().scale(f);
            a.setDeltaMovement(v.x, 0.4, v.z);
            a.hurtMarked = true;
        }
    }

    static void efeito(LivingEntity e, MobEffect ef, int seg, int amp) {
        e.addEffect(new MobEffectInstance(ef, seg * 20, amp));
    }

    static void curar(ServerPlayer p, float v) {
        p.heal(v);
    }

    static void purificar(ServerPlayer p) {
        p.removeEffect(MobEffects.POISON);
        p.removeEffect(MobEffects.WITHER);
        p.removeEffect(MobEffects.WEAKNESS);
        p.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        p.removeEffect(MobEffects.BLINDNESS);
        p.removeEffect(MobEffects.CONFUSION);
        p.removeEffect(MobEffects.HUNGER);
        p.removeEffect(MobEffects.DIG_SLOWDOWN);
    }

    static void sentidos(ServerPlayer p) {
        for (LivingEntity a : area(p, 18)) efeito(a, MobEffects.GLOWING, 6, 0);
    }

    // ---------- movimento ----------
    static void mover(Entity e, double x, double y, double z) {
        if (e instanceof ServerPlayer sp) sp.connection.teleport(x, y, z, sp.getYRot(), sp.getXRot());
        else e.moveTo(x, y, z, e.getYRot(), e.getXRot());
    }

    static void deslocar(ServerPlayer p, double dist, boolean atravessa) {
        ServerLevel w = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 ini = p.position();
        Vec3 melhor = null;
        for (double d = 1.0; d <= dist; d += 0.5) {
            Vec3 c = ini.add(look.x * d, look.y * d, look.z * d);
            BlockPos b = BlockPos.containing(c);
            boolean livre = w.getBlockState(b).getCollisionShape(w, b).isEmpty()
                    && w.getBlockState(b.above()).getCollisionShape(w, b.above()).isEmpty();
            if (livre) melhor = c;
            else if (!atravessa) break;
        }
        if (melhor == null) {
            msg(p, "Caminho bloqueado");
            return;
        }
        mover(p, melhor.x, melhor.y, melhor.z);
        p.fallDistance = 0;
    }

    static void impulso(ServerPlayer p, double f, double y) {
        Vec3 l = p.getLookAngle();
        p.setDeltaMovement(l.x * f, y + l.y * 0.2, l.z * f);
        p.hurtMarked = true;
        p.fallDistance = 0;
    }

    static void gancho(ServerPlayer p, double alc) {
        Vec3 pt = fim(p, alc);
        if (pt.distanceTo(p.getEyePosition()) < 3) {
            msg(p, "Nada para agarrar");
            return;
        }
        raio(p, alc, ParticleTypes.END_ROD);
        Vec3 v = pt.subtract(p.position()).normalize().scale(1.7);
        p.setDeltaMovement(v.x, Math.max(v.y, 0.35), v.z);
        p.hurtMarked = true;
        p.fallDistance = 0;
    }

    static void empurrar(ServerPlayer p, LivingEntity a, double f) {
        Vec3 l = p.getLookAngle();
        a.setDeltaMovement(a.getDeltaMovement().add(l.x * f, 0.3, l.z * f));
        a.hurtMarked = true;
    }

    static void puxar(ServerPlayer p, LivingEntity a) {
        Vec3 l = p.getLookAngle();
        mover(a, p.getX() + l.x * 2, p.getY(), p.getZ() + l.z * 2);
    }

    /** Puxa todos os seres próximos em direção ao jogador. */
    static void atrair(ServerPlayer p, double r, double forca) {
        for (LivingEntity a : area(p, r)) {
            Vec3 v = p.position().subtract(a.position());
            if (v.lengthSqr() < 1e-4) continue;
            v = v.normalize().scale(forca);
            a.setDeltaMovement(a.getDeltaMovement().add(v.x, 0.15, v.z));
            a.hurtMarked = true;
        }
    }

    static void levitar(ServerPlayer p, double r) {
        nuvem(p, ParticleTypes.WITCH, 30);
        for (LivingEntity a : area(p, r)) {
            efeito(a, MobEffects.LEVITATION, 3, 1);
            dano(p, a, 2f);
        }
    }

    // ---------- explosões e raios ----------
    static void boom(ServerPlayer p, Vec3 c, float raio) {
        Heroi h = Herois.atual(p);
        Efeitos.explosaoVisual(p.serverLevel(), c, h != null ? h.cor1 : 0xFFAA33, raio);
        if (!Estado.contido(p)) {
            interno = true;
            try {
                p.serverLevel().explode(p, c.x, c.y, c.z, raio, Level.ExplosionInteraction.NONE);
            } finally {
                interno = false;
            }
        }
    }

    static void explodirEm(ServerPlayer p, LivingEntity a, float d) {
        if (a.isRemoved()) return;
        boom(p, new Vec3(a.getX(), a.getY() + 0.5, a.getZ()), 1.6f);
        dano(p, a, d);
    }

    static void explodirPonto(ServerPlayer p, Vec3 c) {
        boom(p, c, 1.8f);
    }

    static void explosao(ServerPlayer p, double alc, float d) {
        raio(p, alc, ParticleTypes.FLAME);
        LivingEntity a = alvo(p, alc);
        if (a != null) explodirEm(p, a, d);
        else explodirPonto(p, fim(p, alc));
    }

    static void raioVisual(ServerPlayer p, Vec3 pt) {
        ServerLevel w = p.serverLevel();
        LightningBolt b = EntityType.LIGHTNING_BOLT.create(w);
        if (b != null) {
            b.moveTo(pt.x, pt.y, pt.z);
            b.setVisualOnly(true);
            w.addFreshEntity(b);
        }
    }

    static void raioEm(ServerPlayer p, LivingEntity a, float d) {
        raioVisual(p, a.position());
        dano(p, a, d);
        a.setSecondsOnFire(3);
    }

    static void relampago(ServerPlayer p, double alc) {
        LivingEntity a = alvo(p, alc);
        if (a != null) raioEm(p, a, 10f);
        else raioVisual(p, fim(p, alc));
    }
}
