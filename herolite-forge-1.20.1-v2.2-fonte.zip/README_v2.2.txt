HERO LITE v2.2 - ENZO DARK LORD (Forge 1.20.1) - NAO COMPILADO NEM TESTADO AQUI
==============================================================================
IMPORTANTE: apague o zip antigo do herolite (v2.1.0 / 2.0.0) do repositorio ANTES de subir este
(mesmo modid "herolite"). Depois: Actions > Build > Run workflow > baixe o artefato mod-jar.

PASSO ZERO (uma vez): crie o mundo com cheats/ops e rode  /criador registrar  (voce vira o dono).
Depois  /enzo traje  coloca o traje do Enzo Dark Lord em voce (4 pecas).
So o dono (ou quem voce liberar com /enzo permitir <nick>) consegue usar o traje; nas
mãos de outros ele nao faz nada. Nao aparece no menu criativo.

TECLAS (Controles > Hero Lite): R sentidos oniscientes, V/B/N/H habilidades, G modo,
  Z = "tecla 5" (5a tecla; os numeros 1-9 conflitam com a hotbar, entao use Z ou remapeie):
  Z = transforma entre Enzo Dark Lord e ARMADURA COSMICA (skin colorida, dano x40 em vez de x8).
  Agachado + Z = forma cosmica original por 1 min (ultimo recurso, dano em massa, recarga 3 min).

PASSIVAS (traje ativo): forca/resistencia/velocidade enormes, voo, invulneravel a TUDO (inclusive
  /kill e o vazio), imortal, regeneracao, traje inquebravel. Dano total = muito acima dos outros trajes.
  Sem recargas.  Energia/dano que atingem voce e absorvido (aumenta seu dano), projeteis voltam,
  o atacante leva o dano refletido e o dano e transferido ao mob vinculado (/enzo vinculo) ou a
  qualquer monstro vivo carregado.

HABILIDADES  (a variacao depende de como voce esta: agachado > ambiente (outra dimensao, chuva, noite,
  agua) > no ar > normal)
  V  normal: feixe cosmico | ar: chuva de meteoros | agachado: chama cosmica | ambiente: feixe do Poder + raio
  B  normal: teleporte | ar: acelerar tempo (voce rapido, inimigos lentos) | agachado: PARAR O TEMPO | ambiente: PRISAO COSMICA
  N  normal: posse/dominar mente | ar: manifestar medos | agachado: drenar alma | ambiente: reescrever realidade (blocos voltam em 30s)
  H  normal: APAGAR DA EXISTENCIA (mire) | ar: restaurar/curar + revive o ultimo apagado | agachado: necromancia (5 servos)
     | ambiente: supernova.   Na forma cosmica tudo e ~1,8x maior.

COMANDOS /enzo  (so o dono)
  traje | permitir <nick> | negar <nick>
  conceder <alvos> <1-100> / retirar <alvos>   (fragmentos de poder: semideuses, bem abaixo de voce)
  poder <alvos> <forca|velocidade|regeneracao|tanque|visao|invisibilidade|aquatico|pulo|fogo|sorte|escudo|voo> / tirarpoder <alvos>
  dar <jogador> <qtd> <item>   |  desejo <jogador>  (le o ultimo pedido do chat e entrega trajes/itens do Herolite citados)
  apagar <alvos> | reviver | restaurar | clone [1-5] (clones de golem com poder e vontade propria, 5 min)
  prisao <alvos> | soltar <alvos>   (Dimensao Cosmica: cela de bedrock; nem a morte liberta)
  vinculo <alvo> | clima limpo|chuva|trovao | invisivel | intangivel (modo espectador) 
  materia <bloco> <raio 1-16>  (reescreve a materia onde voce olha)
  absorver (mire num mob/chefe/NPC de qualquer mod) | invocar <tipo> | copiar <jogador> | assumir <heroi|nenhum>
  canalizar <acessorio> (usa o poder de um item sem te-lo) | imbuir (item da mao: inquebravel, encantos max, +300 dano)
  cristal [jogador] | nivel <heroi> <x> | desativar <heroi> true|false (remove poderes do traje)
  semfraqueza <heroi> true|false | lista
Itens: Nucleo Sombrio (dark_core): clique direito imbui o item da outra mao (so o dono).

UNICA FRAQUEZA: Cristal Celestial (celestial_crystal). Se estiver no seu inventario, no chao ou com alguem
  a ate 6 blocos, seu poder e selado (fraco, lento, mortal). Nao tem receita e nao esta no menu criativo:
  so /enzo cristal. Quem receber sem sua permissao o ve desfazer-se.
Se o corpo for destruido (cristal), ao renascer o traje e reconstruido.

HONESTIDADE / LIMITES
- Nada foi compilado nem testado. Pode haver erro de compilacao ou bug; mande o log do Actions.
- A skin do Enzo e um design ORIGINAL meu (nao tenho a sua skin). Para usar a sua, troque os PNGs
  assets/herolite/textures/models/armor/enzo_dark_lord_layer_1/2.png e enzo_cosmic_layer_1/2.png (64x32).
- Mudar de tamanho (resize) nao e possivel no 1.20.1 sem outro mod; ficou de fora.
- "Onipotencia" e feita por comandos e habilidades; "copiar/absorver" usa o poder trazendo o ser como aliado
  ou repetindo as habilidades do traje copiado, nao copia mecanicas internas de outros mods.
- A Dimensao Cosmica e uma dimensao de datapack; se seu mundo nao a carregar, a prisao vira uma cela alta
  na mesma dimensao.
- Poderes de personagens futuros e o traje rival: ficam para proximas versoes (a estrutura ja existe).
