Hero Lite v2.0.0 - Forge 1.20.1 (47.x) - Marvel + DC - leve p/ PojavLauncher

IMPORTANTE: este zip e o CODIGO-FONTE. NAO foi compilado nem testado em jogo (sem Forge aqui).
Se o build der erro, mande um print do erro que eu corrijo.

COMO GERAR O .JAR (GitHub, so com o celular)
  1) APAGUE do repositorio o zip antigo do herolite (v1). Dois mods com o mesmo id = erro/jar duplicado.
  2) Add file > Upload files: envie ESTE zip (sem extrair). Se ja tiver outros zips de mods, deixe todos.
  3) .github/workflows/build.yml: cole o conteudo do build.yml deste zip (ele compila TODOS os zips da raiz).
  4) Actions > build > Run workflow. Espere ~10 min. Artifacts > mod-jar.
  5) Coloque o jar (herolite-2.0.0.jar) na pasta mods do Forge 1.20.1.

TECLAS (Controles > Hero Lite)
  R voar/sentidos | V B N habilidades 1-3 | H habilidade 4 | G alternar CONTIDO/TOTAL
  H usa, nesta ordem: item especial na mao > golpe maximo do traje > seu poder proprio.

NOVIDADES
  - 59 personagens (Marvel/DC herois + 16 viloes). /heroi lista
  - Medidores no canto direito: Superman/Supergirl (solar, laranja: sobe ao sol, sol vermelho/kryptonita drenam),
    Pantera Negra (energia cinetica: absorve golpes e devolve), Hulk (furia), Homem de Ferro/Lanterna Verde/
    Ciborgue/Ciclope (carga), Thor/Tempestade (tempestade).
  - CONTIDO: heroi nao mata (deixa 1 de vida), dano reduzido. TOTAL: muito mais forte (e mais ainda contra chefes).
  - Fraquezas: kryptonita, magia, fogo (Marciano/Venom), desidratacao (Aquaman), fome (Flash), EMP (Homem de Ferro)...
  - Visao de calor real (feixe continuo), raios coloridos, explosoes.
  - Itens: Stormbreaker, Anel do Lanterna, Reator Arc, Cinto, Braceletes, Anel do Flash, 6 Joias do Infinito,
    Cetro de Loki, Lanca de Vibranium, Tridente, Godkiller, Pistola Repulsora, Batarangue Explosivo.
    Funcionam sem traje: passivo na mao + habilidade com H ou clique direito.
  - Mobs: Soldado da Hydra, Chitauri, Drone do Ultron, Capanga do Coringa, Parademonio (spawn natural).
    Chefes (so por invocador/ovo): Thanos, Ultron Prime, Doomsday, Darkseid, Doutor Destino (fase 2 abaixo de 50%).
  - Poder proprio: /poder novo <nome> (gasta 1 Cristal de Poder; gratis no criativo), depois
    /poder elemento fogo|gelo|raio|veneno|trevas|luz|vento|terra, /poder forma raio|explosao|onda|projetil|aura,
    /poder forca 1-10, /poder passivo ..., /poder cor FF8800, /poder info, /poder apagar. Evolui com o uso.

COMANDOS (/heroi, precisa de cheats)
  dar <heroi> [jogador] | kit | lista [0-3] | cooldown reset|off|on | energia <0-1000>|max | modo contido|total
  poder <mult> | voo true|false | curar | deus true|false | resetar | mob <tipo>
